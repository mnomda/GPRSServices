﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedPanda.RedPlanning.UI.PerformanceMonitor.GridData
{
    public class PerfDetail
    {
        public PerfDetail()
        {
            Details = new List<PerfDetail>();
        }

        public string Detail { get; set; }
        public List<PerfDetail> Details { get; set; }
    }
}
