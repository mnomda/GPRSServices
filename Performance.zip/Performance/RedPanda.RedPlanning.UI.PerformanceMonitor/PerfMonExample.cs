﻿using System;

namespace RedPanda.RedPlanning.UI.PerformanceMonitor
{
    public class PerfMonExample
    {
        Random r = new Random();
        public Data.Dto.Dto.Performance.PerformanceMonitor SomeMethod() 
        {
            //Brief Description of what is happening here 10-15 chars at most
            Data.Dto.Dto.Performance.PerformanceMonitor monitor = new Data.Dto.Dto.Performance.PerformanceMonitor("Some Method Calculator");

            //Create an "action" for each of the main functions within the system

            for (int q = 0; q < r.Next(2,15); q++)
            {
                int i = SomeOtherMethod(1, 2, monitor.GetAction("Calculation " + q.ToString()));
            }               
         
            return monitor;
        }

        public int SomeOtherMethod(int valA, int valB, Data.Dto.Dto.Performance.PerformanceAction perfAction)
        {
            //var log = perfAction.GetLog();
            System.Threading.Thread.Sleep(r.Next(1, 100));
            //Create individual logs for each of the steps inside the method
            for (int i = 0; i < r.Next(5,50); i++)
            {
                Data.Dto.Dto.Performance.RunLog runlog = perfAction.GetLog("Step "+i.ToString());
                int retunValue = DoSomeWork(valA, valB);
                runlog.StopLog();
            }
            //log.StopLog();
            return 10;
        }

        public int DoSomeWork(int valA, int valB)
        {
            //it is completely irrelevant what happens here. this is simply to simulate something taking long
            System.Threading.Thread.Sleep(r.Next(1, 100));
            return valA + valB;
        }
    }
}
