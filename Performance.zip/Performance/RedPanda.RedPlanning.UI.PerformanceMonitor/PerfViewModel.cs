﻿using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Wpf;
using RedPanda.RedPlanning.Client.WebService.Services;
using RedPanda.RedPlanning.Module.Common.Controls.NestedGrid.Config;
using RedPanda.RedPlanning.UI.PerformanceMonitor.GridData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace RedPanda.RedPlanning.UI.PerformanceMonitor
{

    public class PerfViewModel : NotifyBase
    {
        public Action DataChanged;

        public string SeachText
        {
            get
            {
                if (_seachText == null)
                {
                    _seachText = string.Empty;
                }
                return _seachText;
            }
            set
            {
                _seachText = value;
                Notify(() => PerfMonitorsView);
            }
        }
        private string _seachText { get; set; }
        public DateTime SelectedFromDate { get; set; }
        public DateTime SelectedToDate { get; set; }
        public List<TreeViewItem> PerfMonitorsView
        {
            get
            {
                _perfMonitorsView = new List<TreeViewItem>();

                SelectedPerfMon = null;

                foreach (var monitor in PerfMonitors.OrderByDescending(e => e.Name).ThenBy(e => e.CreatedDate))
                {
                    if (monitor.ToString().ToLowerInvariant().Trim().Contains(SeachText.Trim().ToLowerInvariant()))
                    {
                        TreeViewItem tvo = _perfMonitorsView.FirstOrDefault(d => d.Header.ToString() == monitor.Name);
                        if (tvo == null)
                        {
                            tvo = new TreeViewItem() { Header = monitor.Name };
                            _perfMonitorsView.Add(tvo);
                        }

                        TreeViewItem tvi = new TreeViewItem() { Header = monitor.ToString(), Tag = monitor };
                        tvi.MouseDoubleClick += Tvi_MouseDoubleClick;
                        tvo.Items.Add(tvi);
                        if (SelectedPerfMon == null)
                        {
                            SelectedPerfMon = monitor;
                        }
                        tvo.IsExpanded = false;
                    }

                }
                return _perfMonitorsView;
            }

        }
        private List<TreeViewItem> _perfMonitorsView;

        private void Tvi_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            SelectedPerfMon = (sender as TreeViewItem).Tag as Data.Dto.Dto.Performance.PerformanceMonitor;
        }

        public List<string> PerfNotes
        {
            get
            {

                List<string> values = new List<string>();
                float totalms = SelectedPerfAction.RunLogs.Sum(d => d.TotalMilliSeconds);
                foreach (var log in SelectedPerfAction.StrippedLogs.OrderByDescending(d => d.TotalMilliSeconds))
                {
                    string time = "";

                    if (log.TotalMinutes > 2)
                    {
                        time = log.TotalMinutes.ToString("0.00") + " min(s)";
                    }
                    else if (log.TotalSeconds > 2)
                    {
                        time = log.TotalSeconds.ToString("0.00") + " s";
                    }
                    else
                    {
                        time = log.TotalMilliSeconds.ToString("0.00") + " ms";
                    }
                    values.Add(string.Format("{2}% - {0} - {1}", time, log.Notes,
                       ((log.TotalMilliSeconds / totalms) * 100).ToString("0.00")
                        ));
                }

                return values;

                // return SelectedPerfAction.RunLogs.OrderByDescending(d => d.TotalMilliSeconds).Select(e => e.ToString()).ToList();
            }
        }

        public List<Data.Dto.Dto.Performance.PerformanceMonitor> PerfMonitors
        {
            get
            {
                if (_perfMonitors == null)
                {
                    _perfMonitors = new List<Data.Dto.Dto.Performance.PerformanceMonitor>();
                }
                return _perfMonitors;
            }
            set
            {
                _perfMonitors = value;

                Notify(() => PerfMonitorsView);

            }
        }
        private List<Data.Dto.Dto.Performance.PerformanceMonitor> _perfMonitors;

        public Data.Dto.Dto.Performance.PerformanceMonitor SelectedPerfMon
        {
            get { return _selectedPerfMon; }
            set
            {
                _selectedPerfMon = value;
                PerfSeries = null;
                Notify(() => SelectedPerfMon);
                Notify(() => SelectedPerfMonInfo);
                if (SelectedPerfMon != null)
                {
                    SelectedPerfAction = SelectedPerfMon.PerformanceActions.OrderByDescending(d => d.TotalMilliSeconds).FirstOrDefault();
                }
                DataChanged();
            }
        }
        public Data.Dto.Dto.Performance.PerformanceMonitor _selectedPerfMon;

        public string SelectedPerfMonInfo
        {
            get
            {
                if (SelectedPerfMon != null)
                {
                    int count = SelectedPerfMon.PerformanceActions.Sum(d => d.StrippedLogs.Count());
                    string message = "[" + SelectedPerfMon.CreatedDate.ToString("dd MMM yyyy HH:mm:ss") + "] - Entries Logged:" + count;
                    return message;
                }
                return string.Empty;
            }
        }

        public Data.Dto.Dto.Performance.PerformanceAction SelectedPerfAction
        {
            get { return _selectedPerfAction; }
            set
            {
                _selectedPerfAction = value;
                LogSeries = null;
                Notify(() => SelectedPerfAction);
                Notify(() => PerfNotes);
                SelectedRunLog = SelectedPerfAction.StrippedLogs.OrderByDescending(d => d.TotalMilliSeconds).FirstOrDefault();

            }
        }
        public Data.Dto.Dto.Performance.PerformanceAction _selectedPerfAction;
        public Data.Dto.Dto.Performance.RunLog SelectedRunLog
        {
            get { return _selectedRunLog; }
            set
            {
                _selectedRunLog = value;
                Notify(() => SelectedRunLog);
            }
        }
        public Data.Dto.Dto.Performance.RunLog _selectedRunLog;


        public SeriesCollection PerfSeries
        {
            get
            {

                if (_perfSeries == null)
                {
                    _perfSeries = new SeriesCollection();
                    if (SelectedPerfMon != null)
                    {
                        foreach (Data.Dto.Dto.Performance.PerformanceAction perfAction in SelectedPerfMon.PerformanceActions.OrderByDescending(d => d.TotalMilliSeconds))
                        {
                            PieSeries ps = new PieSeries
                            {
                                Title = perfAction.ActionName,
                                Values = new ChartValues<ObservableValue> { new ObservableValue(perfAction.TotalMilliSeconds) },
                                DataLabels = false,
                                DataLabelsTemplate = null,
                                Tag = perfAction,
                                ToolTip = perfAction
                            };
                            _perfSeries.Add(ps);
                        }
                    }
                }
                return _perfSeries;
            }
            private set
            {
                _perfSeries = null;// serves as a reset
                Notify(() => PerfSeries);
            }
        }
        private SeriesCollection _perfSeries;

        public SeriesCollection LogSeries
        {
            get
            {

                if (_logSeries == null)
                {
                    _logSeries = new SeriesCollection();
                    if (SelectedPerfAction != null)
                    {
                        foreach (Data.Dto.Dto.Performance.RunLog runlog in SelectedPerfAction.StrippedLogs.OrderByDescending(d => d.TotalMilliSeconds))
                        {
                            _logSeries.Add(new PieSeries
                            {
                                Title = runlog.Notes,
                                Values = new ChartValues<ObservableValue> { new ObservableValue(runlog.TotalMilliSeconds) },
                                DataLabels = false,
                                DataLabelsTemplate = null,
                                Tag = runlog,
                                ToolTip = runlog
                            });
                        }
                    }
                }
                return _logSeries;
            }
            private set
            {
                _logSeries = null;// serves as a reset
                Notify(() => LogSeries);
            }
        }
        private SeriesCollection _logSeries;

        public PerfViewModel()
        {
            SelectedFromDate = DateTime.Today.AddDays(-7);
            SelectedToDate = DateTime.Today;
        }

        async public Task RefreshPerformanceMonitors(DateTime from, DateTime to)
        {
            var performanceMonitors = new List<Data.Dto.Dto.Performance.PerformanceMonitor>();
            await Task.Run(() =>
            {
                performanceMonitors = WcfServices.GetProxy().LoadPerfMonitors(from, to);
            });
            PerfMonitors = performanceMonitors;
        }

        public DataConfig<PerfDetail> LoadConfig()
        {
            return new DataConfig<PerfDetail>()
            {
                InnerLayerPropertyName = "Details",
                //create a mapping of the properties in DTO person to the desired layout of the report.
                //DataLayout = new List<ColumnConfig>()
                //{
                //   new ColumnConfig(){ Order =1, ColumnWidth = 150, DisplayName = "Duration", PropertyName = "bleh" },
                //   new ColumnConfig(){ Order =2, ColumnWidth = 500, DisplayName = "Detail", PropertyName = "Detail",Expander = true },
                //},
                //The actual data we want to "print"
                Data = new List<PerfDetail>() { LoadDetails() }
            };
        }

        public PerfDetail LoadDetails()
        {
            if (SelectedPerfMon != null)
            {
                PerfDetail layer1 = new PerfDetail();

                {
                    layer1.Detail = SelectedPerfMon.Name;
                    foreach (var act in SelectedPerfMon.PerformanceActions)
                    {
                        PerfDetail layer2 = new PerfDetail();
                        layer2.Detail = act.ActionName;
                        foreach (var runLog in act.StrippedLogs)
                        {
                            PerfDetail layer3 = new PerfDetail();
                            layer3.Detail = runLog.Notes;
                            foreach (var datum in runLog.AdditionalData)
                            {
                                PerfDetail layer4 = new PerfDetail();
                                layer4.Detail = datum;
                                layer3.Details.Add(layer4);
                            }
                            layer2.Details.Add(layer3);
                        }
                        layer1.Details.Add(layer2);
                    }
                }
                return layer1;
            }
            return null;
        }
    }
}
