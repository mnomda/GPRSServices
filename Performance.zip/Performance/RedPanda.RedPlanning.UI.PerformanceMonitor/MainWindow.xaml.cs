﻿using LiveCharts.Wpf;
using RedPanda.RedPlanning.UI.PerformanceMonitor.GridData;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace RedPanda.RedPlanning.UI.PerformanceMonitor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        PerfViewModel Model;
        public MainWindow()
        {
            InitializeComponent();
            Model = new PerfViewModel();
            DataContext = Model;
            Model.DataChanged = PopulateGrid;
            //Task.Run(() => { ReloadClick(null, null); });
        }
        public void PopulateGrid()
        {
            PerformanceDataGrid.PopulateGrid<PerfDetail>(Model.LoadConfig());
        }

        async private void ReloadClick(object sender, RoutedEventArgs e)
        {
            (sender as Button).IsEnabled = false;
            await Model.RefreshPerformanceMonitors(Model.SelectedFromDate, Model.SelectedToDate);
            (sender as Button).IsEnabled = true;
        }
        private void DataClicked(object sender, LiveCharts.ChartPoint chartPoint)
        {
            Model.SelectedPerfAction = (chartPoint.SeriesView as PieSeries).Tag as Data.Dto.Dto.Performance.PerformanceAction;
        }

        private void DataClickRunLog(object sender, LiveCharts.ChartPoint chartPoint)
        {
            Model.SelectedRunLog = (chartPoint.SeriesView as PieSeries).Tag as Data.Dto.Dto.Performance.RunLog;
        }
        public void CtrlCCopyCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            ListBox lb = (ListBox)(sender);
            var selected = lb.SelectedItem;
            if (selected != null)
                Clipboard.SetText(selected.ToString());
        }

        public void CtrlCCopyCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }


        public void RightClickCopyCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            MenuItem mi = (MenuItem)sender;
            var selected = mi.DataContext;
            if (selected != null)
                Clipboard.SetText(selected.ToString());
        }

        public void RightClickCopyCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
    }
    public class TextInputToVisibilityConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            // Always test MultiValueConverter inputs for non-null
            // (to avoid crash bugs for views in the designer)
            if (values[0] is bool && values[1] is bool)
            {
                bool hasText = !(bool)values[0];
                bool hasFocus = (bool)values[1];

                if (hasFocus || hasText)
                    return Visibility.Collapsed;
            }

            return Visibility.Visible;
        }
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
