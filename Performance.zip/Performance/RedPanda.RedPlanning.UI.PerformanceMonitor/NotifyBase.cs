﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Timers;


namespace RedPanda.RedPlanning.UI.PerformanceMonitor
{
    public class NotifyBase : INotifyPropertyChanged
    {
        private Timer UpdateTimer = new Timer(250) { AutoReset = false }; private List<string> PropsToUpdate = new List<string>();

        public event PropertyChangedEventHandler PropertyChanged;
        public NotifyBase()
        {
            UpdateTimer.Elapsed += Updater_Elapsed;
            UpdateTimer.Start();
        }
        public void Notify<T>(Expression<Func<T>> propertyLambda)
        {
            var me = propertyLambda.Body as MemberExpression;

            if (me == null)
            {
                throw new ArgumentException("You must pass a lambda of the form: '() => Class.Property' or '() => object.Property'");
            }
            string name = me.Member.Name;
            lock (PropsToUpdate)
            {
                if (!string.IsNullOrWhiteSpace(name) && !PropsToUpdate.Contains(name))
                {
                    PropsToUpdate.Add(name);
                }
            }
        }
        private void Updater_Elapsed(object sender, ElapsedEventArgs e)
        {
            UpdateTimer.Stop();
            try
            {
                lock (PropsToUpdate)
                {
                    foreach (string prop in PropsToUpdate.Distinct())// make sure we don't notify the same property more than once a cycle
                    {

                        if (PropertyChanged != null)
                        {
                            PropertyChanged.Invoke(this, new PropertyChangedEventArgs(prop));
                        }
                    }
                    PropsToUpdate.Clear();
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                UpdateTimer.Start();
            }
        }

    }
}
